# This package name shadows the builtin 'code' module
