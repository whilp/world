# Wheels

This directory contains code, metadata files, and wheels, from other projects,
used for testing.  The projects were chosen to match the licence and ownership
of this project, i.e. Apache License 2.0, copyright owned by Google, from the
Google organization repository.  Do not add any other type of thing here.

- [python_portpicker](https://github.com/google/python_portpicker)
- [yapf](https://github.com/google/yapf)
